colors = {
    "background-color": "#091151",
    "text-color": "#f0f0f0",
    "background-card":"#13163c",
    "card-color": "#141661",
    "backgorunf-highlight":"#363479"
}